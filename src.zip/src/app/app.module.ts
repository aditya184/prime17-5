import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {TabMenuModule} from 'primeng/tabmenu';
import {TableModule} from 'primeng/table';
import {InputTextModule} from 'primeng/inputtext';
import { FormsModule } from '@angular/forms';
import {ButtonModule} from 'primeng/button';
import {DropdownModule} from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ReactiveFormsModule} from '@angular/forms';
import {MenuItem} from 'primeng/api';
import {CheckboxModule} from 'primeng/checkbox';
import { NgSelectModule } from '@ng-select/ng-select';
import {SplitButtonModule} from 'primeng/splitbutton';
import {MultiSelectModule} from 'primeng/multiselect';
import {RadioButtonModule} from 'primeng/radiobutton';
import {FileUploadModule} from 'primeng/fileupload';
import {StepsModule} from 'primeng/steps';
import { HttpClientModule } from '@angular/common/http';
import {TabViewModule} from 'primeng/tabview';
import {DialogModule} from 'primeng/dialog';
import {AccordionModule} from 'primeng/accordion';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProjectManagementComponent } from './components/project-management/project-management.component';
import { AddProjectComponent } from './components/project-management/add-project/add-project.component';
import { SelectSowComponent } from './components/select-sow/select-sow.component';
import { ProjectAttributesComponent } from './components/project-attributes/project-attributes.component';
import { TimelineComponent } from './components/timeline/timeline.component';
import { FinanceManagementComponent } from './components/finance-management/finance-management.component';
import { QuickProjectAttributesComponent } from './components/quick-project-attributes/quick-project-attributes.component';
import { SentToClientComponent } from './components/sent-to-client/sent-to-client.component';
import { ClientReviewComponent } from './components/client-review/client-review.component';
import { PendingAllocationComponent } from './components/pending-allocation/pending-allocation.component';
import { InactiveComponent } from './components/inactive/inactive.component';
import { CommunicationsComponent } from './components/communications/communications.component';
import { ManageFinanceComponent } from './components/manage-finance/manage-finance.component';
import { InvoiceTimelineComponent } from './components/invoice-timeline/invoice-timeline.component';


@NgModule({
  declarations: [
    AppComponent,
    ProjectManagementComponent,
    AddProjectComponent,
    SelectSowComponent,
    ProjectAttributesComponent,
    TimelineComponent,
    FinanceManagementComponent,
    QuickProjectAttributesComponent,
    SentToClientComponent,
    ClientReviewComponent,
    PendingAllocationComponent,
    InactiveComponent,
    CommunicationsComponent,
    ManageFinanceComponent,
    InvoiceTimelineComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    TabMenuModule,
    HttpClientModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    DropdownModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    TabViewModule,
    DialogModule,
    StepsModule,
    FileUploadModule,
    RadioButtonModule,
    MultiSelectModule,
    SplitButtonModule,
    NgSelectModule,
    CheckboxModule,
    AccordionModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
