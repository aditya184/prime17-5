import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-client-review',
  templateUrl: './client-review.component.html',
  styleUrls: ['./client-review.component.css']
})
export class ClientReviewComponent implements OnInit {
cols: any;
types: SelectItem[];
data: any;
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.cols = [
      { field: 'proj_code', header: 'Proj. Code' },
      { field: 'client_legal_entity', header: 'Client Legal Entity' },
      { field: 'POC', header: 'POC' },
      { field: 'deliverable_type', header: 'Deliverable Type' },
      { field: 'due_date', header: 'Due Date' },
      { field: 'milestone', header: 'Milestone' },
      { field: 'delivery_date', header: 'Delivery Date' }
  ];

    this.types = [
      { label: 'Abstract', value: 'Abstract' },
      { label: 'Manuscript', value: 'Manuscript' }
    ];

    this.getData();
    }

  getData() {
    this.projectService.getClientReview().then(res => this.data = res);
  }

}
