import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectSowComponent } from './select-sow.component';

describe('SelectSowComponent', () => {
  let component: SelectSowComponent;
  let fixture: ComponentFixture<SelectSowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectSowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectSowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
