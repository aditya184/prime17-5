import { Component, OnInit, Input } from '@angular/core';
import { ProjectService } from '../../services/project.service';

@Component({
  selector: 'app-select-sow',
  templateUrl: './select-sow.component.html',
  styleUrls: ['./select-sow.component.css']
})
export class SelectSowComponent implements OnInit {
data: any;
cols: any = [];
index;
// @Input() message: string;
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.getData();
    this.cols = [
      { field: 'sow_code', header: 'SOW Code' },
      { field: 'sow_title', header: 'SOW Title' },
      { field: 'sow_owner', header: 'SOW Owner' },
  ];
  // console.log(this.message)
  }

  getData() {
    this.projectService.getData().then(res => this.data = res);
  }

  selectSow(sow) {
    console.log(sow);
  }

  nextStep() {
    console.log('Test');
    this.index = 1;
  }

}
