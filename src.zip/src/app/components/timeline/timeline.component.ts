import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
val1 = 'sp';
display = true;
display1 = false;
  constructor() { }

  ngOnInit() {
  }

  valueChange(val) {
    console.log(val);
    if (val === 'sp') {
      this.display = true;
      this.display1 = false;
    } else if (val === 'nsp') {
      this.display1 = true;
      this.display = false;
    }
  }
}
