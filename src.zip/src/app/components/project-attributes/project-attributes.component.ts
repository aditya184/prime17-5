import { Component, OnInit , Input , Output, EventEmitter } from '@angular/core';
import { SelectItem } from 'primeng/api';
import {FormBuilder, FormGroup, FormControl, Validators, NgForm} from '@angular/forms';

@Component({
  selector: 'app-project-attributes',
  templateUrl: './project-attributes.component.html',
  styleUrls: ['./project-attributes.component.css']
})
export class ProjectAttributesComponent implements OnInit {
  billedBy: SelectItem[];
  selectedBilledBy: any;
  addProjectAttributesForm: FormGroup;
  @Output() billedType = new EventEmitter<string>();

  constructor(private frmbuilder: FormBuilder) { }

  ngOnInit() {
    this.initForm();
    this.addProjectAttributesForm.get('clientLeagalEntity').disable();
    this.addProjectAttributesForm.get('billingEntity').disable();
    this.billedBy = [
      { label: 'Deliverable', value: 'Deliverable' },
      { label: 'Hourly', value: 'Hourly' }
    ];
  }

  selectedValue(value) {
    console.log(value);
    console.log(this.selectedBilledBy);
    this.selectedBilledBy = value;
    this.billedType.emit(value);
  }

  initForm() {
    this.addProjectAttributesForm = this.frmbuilder.group({
      clientLeagalEntity: [''],
      subDivision: [''],
      billingEntity: [''],
      billedBy: ['', Validators.required],
      businessVertical: ['', Validators.required],
      projectCode: [''],
      poc: ['', Validators.required],
      poc2: [null],
      therapeuticArea: ['', Validators.required],
      indication: [''],
      molecule: ['', Validators.required],
      priority: ['', Validators.required],
      projectStatus: [''],
      pubSupport: [''],
      pubSupportStatus: [''],
      projectTitle: ['', Validators.required],
      shortTitle: ['', Validators.required],
      endUseDeliverable: [''],
      sowBoxLink: [''],
      conference: [''],
      authors: [''],
      comments: ['']
    });
  }

  addProjectAttributes(data) {
    if (this.addProjectAttributesForm.valid) {
      console.log(data);
    } else {
      this.validateAllFormFields(this.addProjectAttributesForm);
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      // console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        // console.log(control);
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

}
