import { Component, OnInit, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import {TabMenuModule} from 'primeng/tabmenu';
import {MenuItem} from 'primeng/api';
import { ProjectService } from '../../services/project.service';
import {SelectItem} from 'primeng/api';
import {Router} from '@angular/router';
import {FormBuilder, FormGroup, FormControl, Validators, NgForm} from '@angular/forms';

// import { ProjectAttributesComponent } from '../project-attributes/project-attributes.component';

@Component({
  selector: 'app-project-management',
  templateUrl: './project-management.component.html',
  styleUrls: ['./project-management.component.css']
})
export class ProjectManagementComponent implements OnInit {
  items: MenuItem[];
  activeItem: MenuItem;
  data: any;
  cols: any = [];
  allSow: any = [];
  allSowData: any = [];
  types: SelectItem[];
  display = false;
  display1 = false;
  steps: MenuItem[];
  stepsForQuickProject: MenuItem[];
  activeIndex = 0;
  activeIndex1 = 0;
  displayAddProject = false;
  displayAddQuickProject = false;
  step1: any = [];
  step2: any = [];
  selectType: SelectItem[];
  buttons: MenuItem[];
  allsow = 1;
  all = 10;
  sccount = 6;
  crcount = 4;
  pacount = 3;
  inactivecount = 3;
  message: any;
  // budget: any = [];
  budgetData: any;
  // po: any = [];
  // poinfo: any = [];
  // poData = [];
  // poInfoData = [];
  // obj = {};
  // @ViewChild(ProjectAttributesComponent) projectAttributes;
  value: any;
  addSowForm: FormGroup;

  constructor(private frmbuilder: FormBuilder, private router: Router, private projectService: ProjectService) {
  }

  ngOnInit() {
    this.initForm();
    this.addSowForm.get('sowCode').disable();
    this.addSowForm.get('status').disable();
    this.items = [
      {label: 'All Projects'},
      {label: 'Sent to Client'},
      {label: 'Client Review'},
      {label: 'Pending Allocation'},
      {label: 'Inactive Projects'}
    ];
    this.buttons = [
      {label: 'Add SOW', icon: 'pi pi-plus-circle', command: () => {
      this.showDialog();
    }},
    {label: 'Add Quick Project', icon: 'pi pi-plus-circle', command: () => {
      this.addQuickProject();
    }},
  ];
    this.step1[0] = 0;
    this.step2[0] = 0;

    // steps
    this.steps = [{
      label: 'Select Sow',
      command: (event: any) => {
        console.log(event);
        this.step1[event.index] = event.index;
        // this.step1[event.index] = true;
      }
    },
    {
      label: 'Project Attributes',
      command: (event: any) => {
        console.log(event.index);
        this.step1[event.index] = event.index;
      }
    },
    {
      label: 'Timeline',
      command: (event: any) => {
        this.step1[event.index] = event.index;
      }
    },
    {
      label: 'Finance & Management',
      command: (event: any) => {
        this.step1[event.index] = event.index;
      }
    },
    {
      label: 'Communication',
      command: (event: any) => {
        this.step1[event.index] = event.index;
      }
    }];

    this.stepsForQuickProject = [{
        label: 'Select Sow',
        command: (event: any) => {
          console.log(event.index);
          this.step2[event.index] = event.index;
        }
      },
      {
        label: 'Project Attributes',
        command: (event: any) => {
          console.log(event.index);
          this.step2[event.index] = event.index;
        }
      }];


    this.cols = [
      { field: 'sow_code', header: 'SOW code' },
      { field: 'proj_code', header: 'Proj. Code' },
      { field: 'short_title', header: 'Short Title' },
      { field: 'client', header: 'Client' },
      { field: 'deliverable_type', header: 'Deliverable Type' },
      { field: 'project_type', header: 'Proj. Type' },
      { field: 'status', header: 'Status' },
      { field: 'createdBy', header: 'Created By' },
      { field: 'createdDate&Time', header: 'Created Date & Time' }
    ];

    this.allSow = [
      { field: 'sow_code', header: 'SOW code' },
      { field: 'short_title', header: 'Short Title' },
      { field: 'client', header: 'Client' },
      { field: 'poc', header: 'POC' },
      { field: 'createdBy', header: 'Created By' },
      { field: 'createdDate&Time', header: 'Created Date & Time' }
    ];

    // this.budget = [
    //   { field: 'total', header: 'Total' },
    //   { field: 'revenue', header: 'Revenue' },
    //   { field: 'oop', header: 'OOP' },
    //   { field: 'tax', header: 'Tax' },
    //   { field: 'budget_hours', header: 'Budget Hours' }
    // ];

    // this.po = [
    //   // { field: 'number_name', header: 'Number - Name' },
    //   { field: 'total', header: 'Total' },
    //   { field: 'revenue', header: 'Revenue' },
    //   { field: 'oop', header: 'OOP' },
    //   { field: 'tax', header: 'Tax' },
    // ];

    // this.poinfo = [
    //   { field: 'inv_number', header: 'Inv Number' },
    //   { field: 'prf_number', header: 'Prf Number' },
    //   { field: 'date', header: 'Date' },
    //   { field: 'amount', header: 'Amount' },
    //   { field: 'type', header: 'Type' },
    //   { field: 'status', header: 'Status' },
    //   { field: 'poc', header: 'POC' },
    //   { field: 'address', header: 'Address' },
    // ];

    this.types = [
      { label: 'Abstract', value: 'Abstract' },
      { label: 'Manuscript', value: 'Manuscript' }
    ];

    this.selectType = [
      {label: 'Select Type', value: null},
      { label: 'Abstract', value: 'Abstract' },
      { label: 'Manuscript', value: 'Manuscript' }
    ];

    this.getData();
    // this.getBudget();
    // this.getPo();
    // this.getPoInfo();
    this.getAllSow();
  }

  initForm() {
    this.addSowForm = this.frmbuilder.group({
      clientLegalEntity: ['', Validators.required],
      clientPointofContact: ['', Validators.required],
      clientPointofContactOptional: [null],
      cactusBillingEntity: ['', Validators.required],
      businessVertical: ['', Validators.required],
      sowCode: [null, Validators.required],
      sowTitle: ['', Validators.required],
      sowCreationDate: ['', Validators.required],
      sowExpiryDate: ['', Validators.required],
      currency: ['', Validators.required],
      status: ['', Validators.required],
      sowDocument: [''],
      comments: ['', Validators.required],
      total: ['', Validators.required],
      net: ['', Validators.required],
      oop: ['', Validators.required],
      tax: ['', Validators.required],
      cm: ['', Validators.required],
      cm2: ['', Validators.required],
      deliveryOptional: [''],
      delivery: ['', Validators.required],
      sowOwner: ['', Validators.required]
    });
  }

  addSow(data) {
    if (this.addSowForm.valid) {
    console.log(data);
    } else {
      this.validateAllFormFields(this.addSowForm);
    }
  }
  getData() {
    this.projectService.getProjects().then(res => this.data = res);
  }

  // getBudget() {
  //   this.projectService.getBudget().then(res => this.budgetData = res);
  // }

  // getPo() {
  //   this.projectService.getPo().then(res => this.poData = res);
  // }

  // getPoInfo() {
  //   this.projectService.getPoInfo().then(res => this.poInfoData = res);
  // }

  getAllSow() {
    this.projectService.getAllSow().then(res => this.allSowData = res);
  }

  close() {
    console.log('Test');
  }

  getValue(event) {
    console.log(event);
    this.value = event;
    // this.obj['value']=event;
  }

  // add() {
  //   if (this.value === 'Deliverable') {
  //   this.obj['value'] = true;
  //   this.obj['total'] = this.budgetData[0].total;
  //   this.obj['net'] = this.budgetData[0].revenue;
  //   this.obj['oop'] = this.budgetData[0].oop;
  //   this.obj['tax'] = this.budgetData[0].tax;
  //   this.obj['budget_hours'] = this.budgetData[0].budget_hours;
  //   this.obj['podata'] = this.poData;
  //   this.obj['poinfodata'] = this.poInfoData;
  //   }
  // }

  showDialog() {
    this.display = true;
  }

  showDialog1() {
    this.displayAddProject = true;
  }

  addQuickProject() {
    this.displayAddQuickProject = true;
  }

  receiveData(event) {
    this.display1 = event;
  }

  getBudgetData(event) {
    console.log('ashdgjsahdaj', event);
    this.budgetData = event;
  }

  nextStep(index) {
    console.log(index);
    this.step2[index + 1] = index + 1;
    this.activeIndex1 = index + 1;
  }

  prevStep(index) {
    console.log(index);
    this.step2[index - 1] = index - 1;
    this.activeIndex1 = index - 1;
  }

  filterItem(value) {
    console.log(value.toLowerCase());
    if (!value) {
        this.getData();
    }
    this.data = Object.assign([], this.data).filter(
       item => console.log(item)
    );
 }

 reset() {
   this.addSowForm.reset();
 }

 validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    // console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
      // console.log(control);
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
}

}
