import { Component, OnInit } from '@angular/core';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-communications',
  templateUrl: './communications.component.html',
  styleUrls: ['./communications.component.css'],
  providers: [MessageService]
})
export class CommunicationsComponent implements OnInit {
documentData: any = [];
selectedData: any = [];
msgs: Message[] = [];

  constructor(private messageService: MessageService) { }

  ngOnInit() {
    this.documentData = [
      { documentName: 'ewytqyw', modified_by: 'sadashjg', modified_date: 'May 15 , 2019 11:30 AM' },
      { documentName: 'asdjsjk', modified_by: 'ncbvxznb', modified_date: 'May 15 , 2019 12:00 AM' }
  ];
  }

  download(data) {
    if (data.length > 0) {
      console.log(data);
    } else {
      this.showError();
    }
  }

  showError() {
    this.msgs = [];
    this.msgs.push({severity: 'error', summary: 'Error Message', detail: 'Please Select at least one checkbox'});
  }
}
