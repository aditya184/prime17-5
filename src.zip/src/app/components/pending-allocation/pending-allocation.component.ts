import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-pending-allocation',
  templateUrl: './pending-allocation.component.html',
  styleUrls: ['./pending-allocation.component.css']
})
export class PendingAllocationComponent implements OnInit {
cols: any;
types: SelectItem[];
data: any;

  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.cols = [
      { field: 'proj_code', header: 'Proj. Code' },
      { field: 'client', header: 'Client' },
      { field: 'POC', header: 'POC' },
      { field: 'deliverable_type', header: 'Deliverable Type' },
      { field: 'ta', header: 'TA' },
      { field: 'molecule', header: 'Molecule' },
      { field: 'primary_resource', header: 'Primary Resource' },
      { field: 'milestone', header: 'Milestone' },
      { field: 'status', header: 'Status' }
  ];

    this.types = [
      { label: 'Abstract', value: 'Abstract' },
      { label: 'Manuscript', value: 'Manuscript' }
    ];

    this.getData();
    }

  getData() {
    this.projectService.getPendingData().then(res => this.data = res);
  }

}
