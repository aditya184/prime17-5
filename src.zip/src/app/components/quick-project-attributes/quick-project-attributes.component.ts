import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-quick-project-attributes',
  templateUrl: './quick-project-attributes.component.html',
  styleUrls: ['./quick-project-attributes.component.css']
})
export class QuickProjectAttributesComponent implements OnInit {
  billedBy: SelectItem[];
  selectedBilledBy: any;
  budget = false;
  rate = false;
  poBudget = false;
  poList: SelectItem[];
  selectedPo: any;
  constructor() { }

  ngOnInit() {
    this.billedBy = [
      { label: 'Deliverable', value: 'Deliverable' },
      { label: 'Hourly', value: 'Hourly' }
    ];

    this.poList = [
      { label: 'Po_1', value: 'Po_1' },
      { label: 'Po_2', value: 'Po_2' }
    ];
  }

  selectedValue(value: string) {
    console.log(value);
    if (value === 'Deliverable') {
      if (this.selectedPo) {
        this.poBudget = true;
      } else {
        this.poBudget = false;
      }
      this.budget = true;
      this.rate = false;
    } else if (value === 'Hourly') {
      this.rate = true;
      this.budget = false;
      this.poBudget = false;
    } else {
      this.rate = false;
      this.budget = false;
      this.poBudget = false;
    }
  }

  selectedPoData(selectedPo: any) {
    if (selectedPo) {
      if (this.budget) {
        this.poBudget = true;
      } else {
        this.poBudget = false;
      }
    } else {
      this.poBudget = false;
    }
  }
}
