import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/services/project.service';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-sent-to-client',
  templateUrl: './sent-to-client.component.html',
  styleUrls: ['./sent-to-client.component.css']
})
export class SentToClientComponent implements OnInit {
cols: any = [];
data: any = [];
types: SelectItem[];
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.cols = [
      { field: 'proj_code', header: 'Proj. Code' },
      { field: 'client_legal_entity', header: 'Client Legal Entity' },
      { field: 'POC', header: 'POC' },
      { field: 'deliverable_type', header: 'Deliverable Type' },
      { field: 'due_date', header: 'Due Date' },
      { field: 'milestone', header: 'Milestone' },
      { field: 'previous_task_owner', header: 'Previous Task Owner' },
      { field: 'previous_task_status', header: 'Previous Task Status' }
  ];

    this.types = [
      { label: 'Abstract', value: 'Abstract' },
      { label: 'Manuscript', value: 'Manuscript' }
    ];

    this.getData();
    }

    getData() {
      this.projectService.getClient().then(res => this.data = res);
    }
}
