import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SentToClientComponent } from './sent-to-client.component';

describe('SentToClientComponent', () => {
  let component: SentToClientComponent;
  let fixture: ComponentFixture<SentToClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SentToClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SentToClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
