import { Component, OnInit, Output, Input, EventEmitter, OnChanges, SimpleChanges} from '@angular/core';
import { ProjectService } from '../../services/project.service';
import { SelectItem } from 'primeng/api';
import {FormBuilder, FormGroup, FormControl, Validators, NgForm} from '@angular/forms';
import {Message} from 'primeng/components/common/api';


@Component({
  selector: 'app-manage-finance',
  templateUrl: './manage-finance.component.html',
  styleUrls: ['./manage-finance.component.css']
})
export class ManageFinanceComponent implements OnInit , OnChanges {
  budgetData = [];
  budget: any = [];
  obj = {};
  poObj = {};
  value: any;
  po: any = [];
  poinfo: any = [];
  poData = [];
  poInfoData = [];
  ponumber: any;
  hours: any;
  tot: any;
  poList: SelectItem[];
  showPo = false;
  showDelete = true;
  showAdd = true;
  poRevenue: any;
  po_oop: any;
  potax: any;
  scheduleTotal: any = 0 ;
  scheduleRevenue: any = 0;
  scheduleOop: any = 0;
  scheduleTax: any = 0;
  showAddInvoiceDetails = false;
  primaryPoc: SelectItem[];
  address: SelectItem[];
  showInvoice = false;
  addForm: FormGroup;
  unassignedBudget: any;
  revenue: any;
  oop: any;
  tax: any;
  msgs: Message[] = [];
  showSave = false;
  @Input() billedBy: any;
  @Output() budgetdata = new EventEmitter<any>();
  constructor(private frmbuilder: FormBuilder, private projectService: ProjectService) {
    this.addForm = frmbuilder.group({
      date: ['', Validators.required],
      amount: ['', Validators.required],
      primarypoc: ['', Validators.required],
      address: ['', Validators.required]
    });
   }

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
    console.log(this.scheduleTotal);
  }

  ngOnInit() {
    console.log('Manage Finance');
    this.budget = [
      { field: 'total', header: 'Total' },
      { field: 'revenue', header: 'Revenue' },
      { field: 'oop', header: 'OOP' },
      { field: 'tax', header: 'Tax' },
      { field: 'budget_hours', header: 'Budget Hours' }
    ];

    this.budgetData = [
      { total: 0, revenue: 0 , oop: 0, tax: 0, budget_hours: 0 }
    ];

    this.poData = [
      { total: 0, revenue: 0 , oop: 0, tax: 0}
    ];

    this.poInfoData = [
      {inv_number: '', prf_number: '', date: '', amount: '', type : '' , status: '', poc: '', address: ''}
    ];

    this.unassignedBudget = [
      { total: 0, revenue: 0 , oop: 0, tax: 0}
    ];

    this.poList = [
      { label: 'PO 001', value: 'PO-001' },
      { label: 'PO 002', value: 'PO-002' }
    ];

    this.primaryPoc = [
      { label: 'TestPOC' , value: 'TestPOC'},
    ];

    this.address = [
      { label: 'POC', value: 'POC' },
    ];
    // this.po = [
    //   // { field: 'number_name', header: 'Number - Name' },
    //   { field: 'total', header: 'Total' },
    //   { field: 'revenue', header: 'Revenue' },
    //   { field: 'oop', header: 'OOP' },
    //   { field: 'tax', header: 'Tax' },
    // ];

    // this.poinfo = [
    //   { field: 'inv_number', header: 'Inv Number' },
    //   { field: 'prf_number', header: 'Prf Number' },
    //   { field: 'date', header: 'Date' },
    //   { field: 'amount', header: 'Amount' },
    //   { field: 'type', header: 'Type' },
    //   { field: 'status', header: 'Status' },
    //   { field: 'poc', header: 'POC' },
    //   { field: 'address', header: 'Address' },
    // ];

    // this.getBudget();
    // this.getPo();
    // this.getPoInfo();
    this.ponumber = this.poData[0].number_name;

  }

  add() {
    if (this.tot != null && this.hours != null) {
    console.log(this.tot, this.hours);
    this.budgetData[0].total = this.tot;
    this.budgetData[0].revenue = this.tot;
    this.budgetData[0].budget_hours = this.hours;
    this.unassignedBudget[0].total = this.tot;
    this.unassignedBudget[0].revenue = this.tot;
    this.tot = '';
    this.hours = '';
    if (this.billedBy === 'Deliverable') {
      this.obj['value'] = true;
      this.obj['total'] = this.budgetData[0].total;
      this.obj['net'] = this.budgetData[0].revenue;
      this.obj['oop'] = this.budgetData[0].oop;
      this.obj['tax'] = this.budgetData[0].tax;
      this.obj['budget_hours'] = this.budgetData[0].budget_hours;
      this.obj['podata'] = this.poData;
      this.obj['poinfodata'] = this.poInfoData;
      // this.budgetdata.emit(this.obj);
    }
  } else {
    console.log('error');
    this.msgs = [];
    this.msgs.push({severity: 'error', summary: 'Error Message', detail: 'please add budget value'});
  }
  }


  addPoToProject(po) {
    if (po != null) {
    console.log(po);
    this.po = po;
    this.showPo = true;
    } else {
      console.log('error');
    }
  }

  schedulePo() {
    if (this.poRevenue != null && this.po_oop != null && this.potax != null) {
    this.poData[0].total = this.poData[0].total + this.poRevenue;
    this.poData[0].revenue = this.poData[0].revenue + this.poRevenue;
    this.poData[0].oop = this.poData[0].oop + this.po_oop;
    this.poData[0].tax = this.poData[0].tax + this.potax;
    console.log(this.poData);
    if (this.unassignedBudget[0].total !== 0 && this.unassignedBudget[0].revenue !== 0) {
    this.unassignedBudget[0].total = this.unassignedBudget[0].total - this.poRevenue;
    this.unassignedBudget[0].revenue = this.unassignedBudget[0].revenue - this.poRevenue;
    this.unassignedBudget[0].oop = this.unassignedBudget[0].oop - this.po_oop;
    this.unassignedBudget[0].tax = this.unassignedBudget[0].tax - this.potax;
    }

    console.log(this.unassignedBudget);
    this.revenue = this.poRevenue;
    this.oop = this.po_oop;
    this.tax = this.potax;
    this.poRevenue = '';
    this.po_oop = '';
    this.potax = '';
    this.showInvoice = true;
    console.log(this.scheduleTotal);
    if (this.unassignedBudget[0].total === 0) {
      this.showAdd = false;
    }

    } else {
      console.log('error');
    }
  }

  scheduleInvoice() {
    this.showAddInvoiceDetails = true;
  }

  addInvoiceDetails(addForm: NgForm) {
    if (addForm.valid) {
    console.log(addForm.value);
    this.scheduleTotal = this.scheduleTotal + this.revenue;
    this.scheduleRevenue = this.scheduleRevenue + this.revenue;
    this.scheduleOop = this.scheduleOop + this.oop;
    this.scheduleTax = this.scheduleTax + this.tax;

    this.poObj['date'] = addForm.value.date;
    this.poObj['amount'] = addForm.value.amount;
    this.poObj['type'] = 'revenue';
    this.poObj['status'] = 'Not Saved';
    this.poObj['poc'] = addForm.value.primarypoc;
    this.poObj['address'] = addForm.value.address;

    this.poInfoData.push(this.poObj);

    // this.poInfoData[0].date = addForm.value.date;
    // this.poInfoData[0].amount = addForm.value.amount;
    // this.poInfoData[0].type = 'revenue';
    // this.poInfoData[0].status = 'Not Saved';
    // this.poInfoData[0].poc = addForm.value.primarypoc;
    // this.poInfoData[0].address = addForm.value.address;
    console.log(this.poInfoData);
    if (this.scheduleTotal === this.budgetData[0].total) {
      // this.showAdd = false;
      this.showSave = true;
    }
    this.showAddInvoiceDetails = false;
    this.showDelete = false;
    this.showInvoice = false;

    this.poRevenue = '';
    this.po_oop = '';
    this.potax = '';
    } else {
      this.validateAllFormFields(this.addForm);
    }

  }

  getBudget() {
    this.projectService.getBudget().then(res => this.budgetData = res);
  }

  getPo() {
    this.projectService.getPo().then(res => this.poData = res);
  }

  getPoInfo() {
    this.projectService.getPoInfo().then(res => this.poInfoData = res);
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      // console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        console.log(control);
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
