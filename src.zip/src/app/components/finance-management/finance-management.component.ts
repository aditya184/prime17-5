import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges, SimpleChange} from '@angular/core';

@Component({
  selector: 'app-finance-management',
  templateUrl: './finance-management.component.html',
  styleUrls: ['./finance-management.component.css']
})
export class FinanceManagementComponent implements OnInit, OnChanges {
value = 'true';
@Output() dataEvent = new EventEmitter<string>();
@Input() billedBy: any;
@Input() budgetData: any;
budget = false;
rate = false;
request: any = [];
total: any;
budgethours: any;
oop: any;
tax: any;
net: any;
poDisplay = false;
po: any;
poinfo: any;
poData: any;
poInfoData: any;

  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
    console.log(this.budgetData);
    if (this.billedBy === 'Deliverable' && changes.budgetData.currentValue !== undefined) {
      this.total = changes.budgetData.currentValue.total;
      this.oop = changes.budgetData.currentValue.oop;
      this.net = changes.budgetData.currentValue.net;
      this.tax = changes.budgetData.currentValue.tax;
      this.budgethours = changes.budgetData.currentValue.budget_hours;
      this.poDisplay = changes.budgetData.currentValue.value;

      this.poData = this.budgetData.podata;
      this.poInfoData = this.budgetData.poinfodata;
    }
  }

  ngOnInit() {
    console.log(this.billedBy);
    // console.log(this.budgetData);
    this.po = [
      // { field: 'number_name', header: 'Number - Name' },
      { field: 'total', header: 'Total' },
      { field: 'revenue', header: 'Revenue' },
      { field: 'oop', header: 'OOP' },
      { field: 'tax', header: 'Tax' },
    ];
    this.poinfo = [
      { field: 'inv_number', header: 'Inv Number' },
      { field: 'prf_number', header: 'Prf Number' },
      { field: 'date', header: 'Date' },
      { field: 'amount', header: 'Amount' },
      { field: 'type', header: 'Type' },
      { field: 'status', header: 'Status' },
      { field: 'poc', header: 'POC' },
      { field: 'address', header: 'Address' },
    ];
    this.request = [
      { label: 'Yes', value: 'yes' },
      { label: 'No', value: 'no' }
    ];
    if (this.billedBy != null) {
      if (this.billedBy === 'Deliverable') {
        this.budget = true;
        this.rate = false;
      } else {
        this.budget = false;
        this.rate = true;
      }
    } else {
      this.budget = false;
      this.rate = false;
    }
  }

  showDialog() {
    this.dataEvent.emit(this.value);
  }
}
