import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-invoice-timeline',
  templateUrl: './invoice-timeline.component.html',
  styleUrls: ['./invoice-timeline.component.css']
})
export class InvoiceTimelineComponent implements OnInit {
  invoiceTimeline = [];
  invoiceTimelineData = [];
  types: SelectItem[];
  constructor() { }

  ngOnInit() {
    this.invoiceTimeline = [
      { field: 'date_time', header: 'Date & Time' },
      { field: 'activity_type', header: 'Activity Type' },
      { field: 'activity_sub_type', header: 'Activity Sub-Type' },
      { field: 'activity_by', header: 'Activity By' },
      { field: 'activity_description', header: 'Activity Description' },
      { field: 'file_uploaded', header: 'File Uploaded' }
    ];

    this.invoiceTimelineData = [
      {date_time: '17/05/19 12:00 hrs', activity_type: 'Invoice Paid', activity_sub_type: 'Activity Sub Type', activity_by: 'Aditya Joshi' ,
       activity_description: 'Activity Description' , file_uploaded: ''},
      {date_time: '17/05/19 12:00 hrs', activity_type: 'Invoice Paid', activity_sub_type: 'Activity Sub Type', activity_by: 'Aditya Joshi' ,
       activity_description: 'Activity Description' , file_uploaded: ''},
      {date_time: '17/05/19 12:00 hrs', activity_type: 'Activity Type', activity_sub_type: 'Activity Sub Type',
       activity_by: 'Aditya Joshi' , activity_description: 'Activity Description' , file_uploaded: ''},
      {date_time: '17/05/19 12:00 hrs', activity_type: 'Invoice Confirmed', activity_sub_type: 'Activity Sub Type', 
      activity_by: 'Aditya Joshi' , activity_description: 'Activity Description' , file_uploaded: ''}
    ];

    this.types = [
      { label: 'Invoice Paid', value: 'Invoice Paid' },
      { label: 'Activity Type', value: 'Activity Type' },
      { label: 'Invoice Confirmed', value: 'Invoice Confirmed' }
    ];
  }

}
