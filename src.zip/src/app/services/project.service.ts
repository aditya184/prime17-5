import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http: HttpClient) { }

  getProjects() {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getClient() {
    return this.http.get<any>('assets/data/sent-to-client.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getClientReview() {
    return this.http.get<any>('assets/data/client-review.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }
  getPendingData() {
    return this.http.get<any>('assets/data/pending.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getInactiveData() {
    return this.http.get<any>('assets/data/inactive.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getData() {
    return this.http.get<any>('assets/data/sow.json')
    .toPromise()
    .then(res => res.data)
    .then(data => { return data; });
  }

  getBudget() {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.budget)
    .then(data => { return data; });
  }

  getPo() {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.po)
    .then(data => { return data; });
  }

  getPoInfo() {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.poinfo)
    .then(data => { return data; });
  }

  getAllSow() {
    return this.http.get<any>('assets/data/projects.json')
    .toPromise()
    .then(res => res.allsow)
    .then(data => { return data; });
  }
}
