import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectManagementComponent } from './components/project-management/project-management.component';
import { AddProjectComponent } from './components/project-management/add-project/add-project.component';
import { SelectSowComponent } from './components/select-sow/select-sow.component';
import { InvoiceTimelineComponent } from './components/invoice-timeline/invoice-timeline.component';

const routes: Routes = [
  { path: '', component: ProjectManagementComponent },
  { path: 'add', component: AddProjectComponent },
  { path: 'selectsow' , component: SelectSowComponent },
  { path: 'invoice-timeline' , component: InvoiceTimelineComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
